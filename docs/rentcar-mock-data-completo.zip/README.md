# RentCar — dados mockados

## Conteúdo
- `data/clients.json`: 30 clientes, com `image` apontando para `/public/images/clients/`.
- `data/vehicles.json`: 30 veículos, com `image` apontando para `/public/images/vehicles/`.
- `data/rentals.json`: 30 locações, referenciando clientes e veículos por `clienteId` e `veiculoId`, além de `image` para `/public/images/rentals/`.
- `data/dashboard-metrics.json`: 10 métricas de exemplo derivadas dos três arquivos e suas regras de cálculo.
- `data/index.json`: índice dos arquivos, relacionamentos e padrões dos caminhos de imagem.
- `public/images/`: 90 imagens JPG geradas por IA.

## Como usar no Vite/React
Copie a pasta `public` para a raiz do projeto e a pasta `data` para `src/data/mock/` (ou outro local de sua preferência). As URLs das imagens permanecem no formato `/images/...`.

Exemplo: `<img src={client.image} alt={client.name} />`.

## Relacionamentos
Cada locação tem `clienteId` que corresponde a `clients.id` e `veiculoId` que corresponde a `vehicles.id`. Os nomes `cliente` e `veiculo` também estão incluídos para facilitar a exibição inicial em tabelas.

## Métricas
O arquivo de métricas é um snapshot mockado para o dashboard. Em uma implementação real, derive os valores no serviço a partir dos dados atuais, preferencialmente na API. Veja `dashboard-metrics.json` para definições de cálculo.

## Observação
Todos os dados pessoais, telefones, CPFs, placas e valores são fictícios e destinados apenas a testes.
